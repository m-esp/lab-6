class Ability
  include CanCan::Ability

  def initialize(user)
    # Define abilities for the passed in user here. For example:
    user ||= User.new  # guest user (not logged in)
    
    # Public access for viewing posts and comments
    can :read, Post
    can :read, Comment

    if user.present?  # If the user is logged in
      # Users can create posts and comments
      can :create, Post
      can :create, Comment

      # Users can edit or delete their own posts and comments
      can [:update, :destroy], Post, user_id: user.id
      can [:update, :destroy], Comment, user_id: user.id
    end
  end
end
