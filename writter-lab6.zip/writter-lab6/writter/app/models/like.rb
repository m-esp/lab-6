class Like < ApplicationRecord
  belongs_to :post
end
