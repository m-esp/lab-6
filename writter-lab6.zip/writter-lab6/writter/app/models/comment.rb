class Comment < ApplicationRecord
  # Associations
  belongs_to :post
  belongs_to :user  # This line associates each comment with a user
  
  # Validations
  validates :content, presence: true
  validates :user_id, presence: true  # Ensure comment is linked to a user
end
