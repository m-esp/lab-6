class Post < ApplicationRecord
  # Associations
  belongs_to :user  # This line associates each post with a user
  has_many :comments, dependent: :destroy
  
  # Validations
  validates :title, presence: true, length: { maximum: 100 }
  validates :content, presence: true, length: { minimum: 140 }
  validates :user_id, presence: true  # Ensure post is linked to a user

  # Enum for published status
  enum published: { unpublished: 0, published: 1 }
end
