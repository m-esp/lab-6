Rails.application.routes.draw do
  # Devise routes for authentication (login, signup, logout, etc.)
  devise_for :users

  # Nested routes for posts and comments
  resources :posts do
    resources :comments, only: [:create, :edit, :update, :destroy]
  end

  # Routes for users (show, edit, update)
  resources :users, only: [:show, :edit, :update]

  # Hashtags route
  get '/hashtag/:name', to: 'hashtags#show', as: :hashtag

  # Static pages routes
  get 'about', to: 'pages#about', as: 'about'
  get 'contact', to: 'pages#contact', as: 'contact'

  # Profile edit route
  get 'profile/edit', to: 'profiles#edit', as: 'edit_profile'

  # Root route
  root 'posts#index'
end
